/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.*; 
/**
 *
 * @author pierr
 */
public class list_login {
    public static void createListLogin () {
List ListLogin = new ArrayList();
return ListLogin
}
    public static void createListPassword () {
List ListPassword = new ArrayList();

}
}
