/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package score;

/**
 *
 * @author halil
 */
public class score {
    public static int Score;
    
    
public  static Integer getScore(){
return Score;
}
}




