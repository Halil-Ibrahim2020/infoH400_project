
import com.pixelmed.display.SourceImage;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author pierr
 */
public class course_Histology extends javax.swing.JFrame {

    /**
     * Creates new form course_Histology
     */
    public course_Histology() {
        initComponents();
        
        Container ControlHost = getContentPane();
        ControlHost.setLayout(new FlowLayout());
        
        JTextArea jta = new JTextArea(10, 40);
        jta.setEditable(false);
        jta.setText("L’histologie (du grec ancien ἱστός, « tissu », et λόγος, « discours »), autrefois appelée anatomie microscopique1,2, est la branche de la biologie et de la médecine qui étudie les tissus biologiques. Elle se situe au carrefour de la biologie cellulaire, de l'anatomie, de la biochimie et de la physiologie. Elle a pour objectif d’explorer la structure des organismes vivants, les rapports constitutifs et fonctionnels entre leurs éléments fonctionnels, ainsi que le renouvellement des tissus. Elle participe à l'exploration des processus pathologiques et de leurs effets.\n" +
"\n" +
"\n" +
"Histoire\n" +
"Les prémices de l'histologie adviennent grâce à l'apparition du microscope au XVIIe siècle, bien que ce terme n’advienne que deux siècles après. Il est utilisé pour la première fois en 1819, par Mayer (en) et Heusinger.\n" +
"\n" +
"L'Italien Marcello Malpighi, professeur de médecine à Bologne et à Pise, est considéré comme le fondateur de l'histologie. La discipline fut d'abord empirique, grâce au perfectionnement de microscopes simples, alors récemment inventés, permettant l'étude de coupes minces.\n" +
"\n" +
"\n" +
"Histologie (1950)\n" +
"On doit la notion de tissu biologique à un ouvrage de Xavier Bichat, le Traité des membranes en général et de diverses membranes en particulier (1799). Les tissus sont alors définis comme des ensembles de cellules ayant des caractères morphologiques analogues. Leur classification est alors simple :\n" +
"\n" +
"les tissus épithéliaux ;\n" +
"le tissu musculaire ;\n" +
"le tissu nerveux ;\n" +
"le tissu conjonctif.\n" +
"Ces premières études ont permis l’obtention d’une grande quantité d'informations sur les structures biologiques, ce qui a permis l'élaboration de la théorie cellulaire par Matthias Jakob Schleiden et Theodor Schwann, en 1838. Le terme d'histologie fut utilisé pour la première fois en 1819, par Mayer (en) et Heusinger.\n" +
"\n" +
"La conjonction de la théorie cellulaire et de la mise au point du microscope optique achromatique entraîne la révolution fondatrice de l'histologie. Après la Seconde Guerre mondiale, les chercheurs du Rockfeller Institute for Medical Research de New York jouent un rôle fondamental avec la description des ultrastructures cellulaires et tissulaires grâce à la microscopie électronique. Dans les années 1970 et 1980, une histologie moléculaire se met en place, entraînant notamment une rénovation de la nomenclature et un affinement de la description morphologique3.\n" +
"\n" +
"Les techniques de biologie cellulaire, de biologie moléculaire, de clonage et de génétique moléculaire ont permis de mieux comprendre le fonctionnement cellulaire et les interactions cellulaires. Ainsi, si la cellule constitue bien l'unité fondamentale de la structure des organismes vivants, elle se révèle être un ensemble très sophistiqué. L'histologie moderne considère ainsi la cellule comme une unité fonctionnelle fondamentale.\n" +
"\n" +
"Tissus animaux\n" +
"Schéma d'une cellule animale\n" +
"Structure des cellules animales.\n" +
"Le règne Animalia contient des organismes multicellulaires qui sont hétérotrophes et mobiles (bien que certains aient adopté secondairement un mode de vie sessile). La plupart des animaux ont un corps différencié en tissus distincts : ce sont des eumétazoaires. Ils possèdent une chambre digestive interne, avec une ou deux ouvertures ; les gamètes sont produits dans des organes sexuels multicellulaires et les zygotes comprennent un stade de blastula dans leur développement embryonnaire. Les métazoaires ne comprennent pas les éponges, qui ont des cellules indifférenciées4.\n" +
"\n" +
"Contrairement aux cellules végétales, les cellules animales ne possèdent ni paroi cellulaire, ni chloroplastes. Les vacuoles, lorsqu'elles sont présentes, sont plus nombreuses et beaucoup plus petites que dans la cellule végétale. Les tissus de l'organisme sont composés de nombreux types de cellules, notamment celles des muscles, des nerfs et de la peau. Chacune est composée généralement d'une membrane formée de phospholipides, un cytoplasme et un noyau. Toutes les différentes cellules d'un animal sont dérivées des couches germinales embryonnaires. Les invertébrés les plus simples, qui sont formés à partir de deux couches germinales d'ectoderme et d'endoderme, sont appelés diploblastiques et les animaux plus développés dont les structures et les organes sont formés à partir de trois couches germinales sont appelés triploblastiques5. Tous les tissus et organes d'un animal triploblastique sont dérivés des trois couches germinales de l'embryon : l'ectoderme, le mésoderme et l'endoderme.\n" +
"\n" +
"Les tissus animaux forment quatre types fondamentaux : les tissus conjonctifs, épithéliaux, musculaires et nerveux.\n" +
"\n" +
"Tissus conjonctifs\n" +
"Cartilage hyalin au microscope.\n" +
"Cartilage hyalin coloré à l'hématoxyline et à l'éosine sous lumière polarisée.\n" +
"Les tissus conjonctifs sont fibreux et constitués de cellules dispersées dans un matériau inorganique appelé matrice extracellulaire. Le tissu conjonctif donne sa forme aux organes et les maintient en place. Les principaux types sont le tissu conjonctif lâche, le tissu adipeux, le tissu conjonctif fibreux, le cartilage et l'os. La matrice extracellulaire contient des protéines, dont la principale et la plus abondante est le collagène. Le collagène joue un rôle majeur dans l'organisation et le maintien des tissus. La matrice peut être modifiée pour former un squelette destiné à soutenir ou à protéger le corps. Un exosquelette est une cuticule épaisse et rigide, rigidifiée par la minéralisation, comme chez les crustacés, ou par la réticulation de ses protéines, comme chez les insectes. Un endosquelette est interne et présent chez tous les animaux développés, ainsi que chez de nombreux animaux à la structure plus simple5.\n" +
"\n" +
"Épithélium\n" +
"Muqueuse gastrique.\n" +
"Muqueuse gastrique.\n" +
"Le tissu épithélial se compose de cellules très serrées, liées les unes aux autres par des protéines d'adhésion cellulaire, avec peu d'espace intercellulaire. Les cellules épithéliales peuvent être squameuses (plates), cuboïdes ou cylindriques. Elles reposent sur une lame basale, la couche supérieure de la membrane basale. La couche inférieure est la lame réticulaire située à côté du tissu conjonctif dans la matrice extracellulaire sécrétée par les cellules épithéliales. Il existe de nombreux types d'épithélium différents, modifiés pour répondre à une fonction particulière. Dans les voies respiratoires, il se trouve un type de revêtement épithélial cilié ; dans l'intestin grêle, il existe des microvillosités sur le revêtement épithélial et dans le gros intestin, des villosités intestinales. La peau est constituée d'une couche externe d'épithélium pavimenteux stratifié et kératinisé qui recouvre l'extérieur du corps des vertébrés. Les kératinocytes représentent jusqu'à 95 % des cellules de la peau. Les cellules épithéliales de la surface externe du corps sécrètent généralement une matrice extracellulaire sous la forme d'une cuticule. Chez les animaux simples, il peut s'agir d'une simple couche de glycoprotéines5. Chez les animaux plus évolués, de nombreuses glandes sont formées de cellules épithéliales.\n" +
"\n" +
"Tissus musculaires\n" +
"Coupe transversale d'un muscle strié squelettique.\n" +
"Coupe transversale d'un muscle strié squelettique.\n" +
"Les myocytes forment le tissu contractile actif de l'organisme. Le tissu musculaire a pour fonction de produire une force et de provoquer un mouvement, qu'il s'agisse d'une locomotion ou d'un mouvement dans les organes internes. Le muscle est formé de filaments contractiles et se divise en trois types principaux : le muscle lisse, le muscle squelettique et le muscle cardiaque. Le muscle lisse ne présente aucune strie lorsqu'il est examiné au microscope. Il se contracte lentement mais se caractérise par une forte extensibilité. Il s'observe par exemple dans les tentacules des anémones de mer et la paroi corporelle des holothuries. Le muscle squelettique se contracte rapidement, sa plage d'extension reste cependant limitée. Il est visible dans le mouvement des appendices et des mâchoires. Le muscle strié est intermédiaire entre les deux autres. Constitué de filaments décalés, il permet aux vers de terre de s'étendre lentement ou d'effectuer des contractions rapides. Chez les mammifères, les muscles striés se présentent en faisceaux attachés aux os pour assurer le mouvement et sont souvent disposés en ensembles antagonistes. Les muscles lisses se trouvent dans les parois de l'utérus, de la vessie, des intestins, de l'estomac, de l'œsophage, des voies respiratoires et des vaisseaux sanguins. Le muscle cardiaque est présent uniquement dans le cœur, ce qui lui permet de se contracter et de pomper le sang dans tout le corps.\n" +
"\n" +
"Tissus nerveux\n" +
"Motoneurone de la moelle épinière.\n" +
"Motoneurone de la moelle épinière.\n" +
"Le tissu nerveux est composé de nombreuses cellules nerveuses appelées neurones qui transmettent des informations. Chez certains animaux marins à symétrie radiale et à déplacement lent, comme les cténophores et les cnidaires (y compris les anémones de mer et les méduses), les nerfs forment un réseau nerveux, mais chez la plupart des animaux, ils sont organisés longitudinalement en faisceaux. Chez les animaux simples, les neurones récepteurs de la paroi corporelle provoquent une réaction locale à un stimulus. Chez les animaux plus complexes, des cellules réceptrices spécialisées, comme les chimiorécepteurs et les photorécepteurs envoient des messages à d'autres parties de l'organisme le long de réseaux neuronaux. Les neurones peuvent être reliés entre eux dans des ganglions. Chez les mammifères, les récepteurs spécialisés sont à la base des organes des sens et il existe un système nerveux central (cerveau et moelle épinière) et un système nerveux périphérique. Ce dernier se compose de nerfs sensoriels qui transmettent les informations provenant des organes des sens et de nerfs moteurs qui influencent les organes cibles. Le système nerveux périphérique se divise en deux parties : le système nerveux somatique, qui transmet les sensations et contrôle les muscles volontaires, et le système nerveux autonome, qui contrôle involontairement les muscles lisses, certaines glandes et les organes internes, dont l'estomac.");
        JScrollPane JSCPane =new JScrollPane(jta, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS );
        Font F = new Font("Verdana", Font.PLAIN, 16);
        jta.setFont(F);
        jta.setLineWrap(true);
        jta.setWrapStyleWord(true);
        ControlHost.add(JSCPane);
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TestHisto = new javax.swing.JButton();
        artere = new javax.swing.JButton();
        jLabelDisplay = new javax.swing.JLabel();

        TestHisto.setText("Test");
        TestHisto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TestHistoActionPerformed(evt);
            }
        });

        artere.setText("Browse");
        artere.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                artereActionPerformed(evt);
            }
        });

        jLabelDisplay.setText("Image");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(artere)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TestHisto)
                .addGap(156, 156, 156))
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabelDisplay, javax.swing.GroupLayout.DEFAULT_SIZE, 341, Short.MAX_VALUE)
                .addGap(334, 334, 334))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(248, 248, 248)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TestHisto)
                    .addComponent(artere))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelDisplay, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TestHistoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TestHistoActionPerformed
Start_quiz S = new Start_quiz();  
S.setVisible(true);
        course_Histology.this.dispose();// TODO add your handling code here:
    }//GEN-LAST:event_TestHistoActionPerformed

    private void artereActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_artereActionPerformed
        JFileChooser jfc = new JFileChooser("D:\\programme école\\dicom_course_histology");
        int returnValue = jfc.showOpenDialog(null);
        if(returnValue == JFileChooser.APPROVE_OPTION){
        File selectedFile = jfc.getSelectedFile();
        loadAndDisplay(selectedFile); // TODO add your handling code here:
    }//GEN-LAST:event_artereActionPerformed
    }
    private void loadAndDisplay(File selectedFile){
    try{
        SourceImage sImg = new SourceImage(selectedFile.getAbsolutePath());
        Image img = sImg.getBufferedImage();
        ImageIcon icon = new ImageIcon(img);
        jLabelDisplay.setIcon(icon);
        
    } catch (Exception ex){
        Logger.getLogger(course_Histology.class.getName()).log(Level.SEVERE, null, ex);
    }

    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(course_Histology.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(course_Histology.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(course_Histology.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(course_Histology.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new course_Histology().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton TestHisto;
    private javax.swing.JButton artere;
    private javax.swing.JLabel jLabelDisplay;
    // End of variables declaration//GEN-END:variables

    private void loadAndDisplay(String cUserspierrOneDrive__Université_Libre_de_) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        
    }
}
